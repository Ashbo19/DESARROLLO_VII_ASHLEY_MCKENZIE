<?php
require_once "database.php";
echo "Conexión exitosa a la base de datos con MySQLi.";
mysqli_close($conn);
?>