//Debe mostrar tabla con todos los productos y enlaces para editar y eliminar.
