<?php
require_once "config_pdo.php";
echo "Conexión exitosa a la base de datos con PDO.";
$pdo = null;
?>