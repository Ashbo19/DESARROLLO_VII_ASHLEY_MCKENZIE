<?php
require_once "config_mysqli.php";
echo "Conexión exitosa a la base de datos con MySQLi.";
mysqli_close($conn);
?>